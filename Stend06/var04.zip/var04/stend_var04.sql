ALTER SYSTEM FLUSH BUFFER_CACHE;
ALTER SYSTEM FLUSH SHARED_POOL;
ALTER SESSION SET TRACEFILE_IDENTIFIER = "article6_var04";

DECLARE
    sid$      v$session.sid%TYPE;
    spid$     v$process.spid%TYPE;
    serial$   v$session.serial#%TYPE;
    strt      TIMESTAMP;
    cmpl      TIMESTAMP;

    TYPE t_row IS RECORD
    (
        USERNAME   VARCHAR2 (30),
        CNT        NUMBER,
        AVERAGE    NUMBER
    );

    TYPE t_table IS TABLE OF t_row
        INDEX BY PLS_INTEGER;

    v_table   t_table;
BEGIN
    SELECT p.spid, s.sid, s.serial#
      INTO spid$, sid$, serial$
      FROM v$process p, v$session s
     WHERE p.addr = s.paddr AND s.audsid = USERENV ('SESSIONID');

    DBMS_OUTPUT.put_line ('SPID: ' || spid$);
    sys.DBMS_SYSTEM.set_ev (sid$,
                            serial$,
                            10046,
                            12,
                            '');
    strt := SYSTIMESTAMP;
    DBMS_OUTPUT.PUT_LINE (TO_CHAR (strt) || ' Started');

    -- start
    SELECT username,
           TO_NUMBER (SUBSTR (data, 1, 10)) cnt,
           TO_NUMBER (SUBSTR (data, 11))    average
      BULK COLLECT INTO v_table
      FROM (SELECT DISTINCT
                   us.username,
                   (SELECT    TO_CHAR (COUNT (*), 'fm0000000009')
                           || AVG (object_id)
                      FROM t_objects obj
                     WHERE us.username = obj.owner)
                       data
              FROM t_users us);

    DBMS_OUTPUT.put_line ('Overall rows ' || v_table.COUNT);
    -- end
    cmpl := SYSTIMESTAMP;
    DBMS_OUTPUT.PUT_LINE (TO_CHAR (cmpl) || ' Completed succesfully');
    DBMS_OUTPUT.PUT_LINE ('Execution duration = ' || TO_CHAR (cmpl - strt));
EXCEPTION
    WHEN OTHERS
    THEN
        DBMS_OUTPUT.PUT_LINE (
            TO_CHAR (SYSTIMESTAMP) || ' Error: ' || SQLERRM);
END;